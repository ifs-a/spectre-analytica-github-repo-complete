-- Spectre Analytica Database Schema (Fixed)
-- Created: 2025-07-30
-- Purpose: Complete database structure for crime risk assessment platform

USE spectre_analytica;

-- Users table for authentication and user management
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    profession ENUM('business', 'tourist', 'government', 'media', 'general', 'law_enforcement', 'security') DEFAULT 'general',
    phone VARCHAR(20),
    organization VARCHAR(100),
    role ENUM('admin', 'user', 'analyst', 'viewer') DEFAULT 'user',
    is_active BOOLEAN DEFAULT TRUE,
    last_login TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_username (username),
    INDEX idx_email (email),
    INDEX idx_role (role)
);

-- Crime incidents table for storing all crime data
CREATE TABLE IF NOT EXISTS crime_incidents (
    id INT AUTO_INCREMENT PRIMARY KEY,
    incident_id VARCHAR(50) UNIQUE,
    crime_type ENUM(
        'kidnapping', 'abduction', 'murder', 'assault', 'assault_gbh',
        'illegal_firearms', 'driving_under_influence', 'common_robbery',
        'robbery_aggravated', 'robbery_cash_transit', 'public_violence',
        'carjacking', 'robbery_residential', 'robbery_non_residential',
        'community_reported', 'political_attacks', 'public_protest'
    ) NOT NULL,
    title VARCHAR(255),
    description TEXT,
    latitude DECIMAL(10, 8) NOT NULL,
    longitude DECIMAL(11, 8) NOT NULL,
    location_name VARCHAR(255),
    address TEXT,
    province VARCHAR(50),
    city VARCHAR(100),
    suburb VARCHAR(100),
    postal_code VARCHAR(10),
    severity_level INT DEFAULT 5 CHECK (severity_level BETWEEN 1 AND 10),
    incident_date DATE NOT NULL,
    incident_time TIME,
    reported_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('active', 'resolved', 'investigating', 'closed') DEFAULT 'active',
    source VARCHAR(100),
    source_url TEXT,
    verified BOOLEAN DEFAULT FALSE,
    casualties INT DEFAULT 0,
    injuries INT DEFAULT 0,
    property_damage DECIMAL(12, 2),
    weather_conditions VARCHAR(50),
    visibility VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_crime_type (crime_type),
    INDEX idx_location (latitude, longitude),
    INDEX idx_incident_date (incident_date),
    INDEX idx_severity (severity_level),
    INDEX idx_province (province),
    INDEX idx_status (status)
);

-- Routes table for storing calculated safe routes
CREATE TABLE IF NOT EXISTS routes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    route_name VARCHAR(100),
    origin_address TEXT NOT NULL,
    origin_lat DECIMAL(10, 8) NOT NULL,
    origin_lng DECIMAL(11, 8) NOT NULL,
    destination_address TEXT NOT NULL,
    destination_lat DECIMAL(10, 8) NOT NULL,
    destination_lng DECIMAL(11, 8) NOT NULL,
    waypoints JSON,
    route_geometry LONGTEXT,
    distance_km DECIMAL(8, 2),
    estimated_time_minutes INT,
    risk_score DECIMAL(3, 1) CHECK (risk_score BETWEEN 0.0 AND 10.0),
    threat_radius_km INT DEFAULT 10,
    travel_time ENUM('morning', 'afternoon', 'evening', 'night'),
    vehicle_type ENUM('sedan', 'suv', 'truck', 'motorcycle', 'public_transport'),
    route_type ENUM('safest', 'fastest', 'balanced') DEFAULT 'safest',
    threats_count INT DEFAULT 0,
    high_risk_areas JSON,
    alternative_routes JSON,
    weather_factor VARCHAR(50),
    traffic_factor VARCHAR(50),
    is_favorite BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_routes (user_id),
    INDEX idx_risk_score (risk_score),
    INDEX idx_created_date (created_at)
);

-- Reports table for storing generated PDF reports
CREATE TABLE IF NOT EXISTS reports (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    route_id INT,
    report_type ENUM('route_assessment', 'area_analysis', 'threat_summary', 'executive_summary') NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    file_name VARCHAR(255),
    file_path TEXT,
    file_size_kb INT,
    report_data JSON,
    executive_summary TEXT,
    risk_assessment TEXT,
    recommendations TEXT,
    charts_included JSON,
    maps_included BOOLEAN DEFAULT FALSE,
    status ENUM('generating', 'completed', 'failed', 'archived') DEFAULT 'generating',
    generated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP NULL,
    download_count INT DEFAULT 0,
    last_downloaded TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (route_id) REFERENCES routes(id) ON DELETE SET NULL,
    INDEX idx_user_reports (user_id),
    INDEX idx_report_type (report_type),
    INDEX idx_status (status),
    INDEX idx_generated_date (generated_at)
);

-- Areas table for storing high-risk and safe zones
CREATE TABLE IF NOT EXISTS areas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    area_name VARCHAR(100) NOT NULL,
    area_type ENUM('high_risk', 'medium_risk', 'low_risk', 'safe_zone', 'police_station', 'hospital', 'checkpoint') NOT NULL,
    description TEXT,
    center_lat DECIMAL(10, 8) NOT NULL,
    center_lng DECIMAL(11, 8) NOT NULL,
    radius_km DECIMAL(6, 3) DEFAULT 1.000,
    province VARCHAR(50),
    city VARCHAR(100),
    suburb VARCHAR(100),
    risk_level INT DEFAULT 5 CHECK (risk_level BETWEEN 1 AND 10),
    incident_count INT DEFAULT 0,
    last_incident_date DATE,
    population_density VARCHAR(20),
    economic_status VARCHAR(20),
    police_presence ENUM('high', 'medium', 'low', 'none') DEFAULT 'medium',
    lighting_quality ENUM('excellent', 'good', 'fair', 'poor') DEFAULT 'fair',
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_area_type (area_type),
    INDEX idx_risk_level (risk_level),
    INDEX idx_location (center_lat, center_lng),
    INDEX idx_province (province)
);

-- Alerts table for real-time notifications
CREATE TABLE IF NOT EXISTS alerts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    alert_type ENUM('route_warning', 'area_alert', 'incident_nearby', 'traffic_update', 'weather_warning') NOT NULL,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    severity ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
    latitude DECIMAL(10, 8),
    longitude DECIMAL(11, 8),
    radius_km DECIMAL(6, 3) DEFAULT 5.000,
    incident_id INT,
    route_id INT,
    is_read BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE,
    expires_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (incident_id) REFERENCES crime_incidents(id) ON DELETE SET NULL,
    FOREIGN KEY (route_id) REFERENCES routes(id) ON DELETE SET NULL,
    INDEX idx_user_alerts (user_id),
    INDEX idx_alert_type (alert_type),
    INDEX idx_severity (severity),
    INDEX idx_is_read (is_read),
    INDEX idx_created_date (created_at)
);

-- Data sources table for tracking scraping sources
CREATE TABLE IF NOT EXISTS data_sources (
    id INT AUTO_INCREMENT PRIMARY KEY,
    source_name VARCHAR(100) NOT NULL,
    source_url TEXT,
    source_type ENUM('government', 'police', 'news', 'community', 'social_media', 'api') NOT NULL,
    description TEXT,
    last_scraped TIMESTAMP NULL,
    scraping_frequency ENUM('hourly', 'daily', 'weekly', 'monthly') DEFAULT 'daily',
    is_active BOOLEAN DEFAULT TRUE,
    reliability_score DECIMAL(3, 2) DEFAULT 0.80 CHECK (reliability_score BETWEEN 0.00 AND 1.00),
    records_scraped INT DEFAULT 0,
    last_error TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_source_type (source_type),
    INDEX idx_is_active (is_active),
    INDEX idx_last_scraped (last_scraped)
);

-- System logs table for audit and monitoring
CREATE TABLE IF NOT EXISTS system_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    action VARCHAR(100) NOT NULL,
    table_name VARCHAR(50),
    record_id INT,
    old_values JSON,
    new_values JSON,
    ip_address VARCHAR(45),
    user_agent TEXT,
    session_id VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_user_logs (user_id),
    INDEX idx_action (action),
    INDEX idx_table_name (table_name),
    INDEX idx_created_date (created_at)
);

-- Insert default admin user
INSERT INTO users (username, email, password_hash, first_name, last_name, role, profession) VALUES
('admin', 'admin@spectreanalytica.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBdXzgVuj3ooiW', 'System', 'Administrator', 'admin', 'law_enforcement')
ON DUPLICATE KEY UPDATE updated_at = CURRENT_TIMESTAMP;

-- Insert sample data sources
INSERT INTO data_sources (source_name, source_url, source_type, description, reliability_score) VALUES
('SAPS Crime Statistics', 'https://www.saps.gov.za/services/crimestats.php', 'government', 'Official South African Police Service crime statistics', 0.95),
('ISS Crime Hub', 'https://issafrica.org/crimehub', 'government', 'Institute for Security Studies crime data hub', 0.90),
('Community Safety Forums', 'https://www.communitysafety.gov.za/', 'community', 'Community-reported crime incidents', 0.75),
('News24 Crime Reports', 'https://www.news24.com/topics/crime', 'news', 'Crime news and incident reports', 0.70)
ON DUPLICATE KEY UPDATE updated_at = CURRENT_TIMESTAMP;

-- Insert sample high-risk areas for major South African cities
INSERT INTO areas (area_name, area_type, center_lat, center_lng, radius_km, province, city, risk_level, description) VALUES
('Johannesburg CBD', 'high_risk', -26.2041, 28.0473, 2.5, 'Gauteng', 'Johannesburg', 8, 'High crime area with frequent incidents'),
('Hillbrow', 'high_risk', -26.1849, 28.0488, 1.5, 'Gauteng', 'Johannesburg', 9, 'Very high crime density area'),
('Cape Town CBD', 'medium_risk', -33.9249, 18.4241, 2.0, 'Western Cape', 'Cape Town', 6, 'Moderate risk with tourist safety concerns'),
('Durban Central', 'medium_risk', -29.8587, 31.0218, 2.0, 'KwaZulu-Natal', 'Durban', 6, 'Moderate risk business district'),
('Sandton', 'low_risk', -26.1076, 28.0567, 3.0, 'Gauteng', 'Johannesburg', 3, 'Well-secured business district'),
('Waterfront Cape Town', 'low_risk', -33.9021, 18.4187, 1.5, 'Western Cape', 'Cape Town', 2, 'Tourist area with good security')
ON DUPLICATE KEY UPDATE updated_at = CURRENT_TIMESTAMP;

-- Insert sample crime incidents
INSERT INTO crime_incidents (incident_id, crime_type, title, latitude, longitude, location_name, province, city, severity_level, incident_date, status, source) VALUES
('INC001', 'murder', 'Homicide Investigation - Johannesburg CBD', -26.2041, 28.0473, 'Johannesburg CBD', 'Gauteng', 'Johannesburg', 9, '2025-07-29', 'investigating', 'SAPS'),
('INC002', 'carjacking', 'Armed Carjacking - Sandton', -26.1076, 28.0567, 'Sandton City', 'Gauteng', 'Johannesburg', 8, '2025-07-29', 'active', 'Community Report'),
('INC003', 'common_robbery', 'Street Robbery - Cape Town CBD', -33.9249, 18.4241, 'Cape Town CBD', 'Western Cape', 'Cape Town', 6, '2025-07-28', 'resolved', 'SAPS'),
('INC004', 'assault', 'Assault Case - Durban Central', -29.8587, 31.0218, 'Durban Central', 'KwaZulu-Natal', 'Durban', 5, '2025-07-28', 'investigating', 'SAPS'),
('INC005', 'kidnapping', 'Kidnapping Report - Hillbrow', -26.1849, 28.0488, 'Hillbrow', 'Gauteng', 'Johannesburg', 10, '2025-07-27', 'active', 'SAPS')
ON DUPLICATE KEY UPDATE updated_at = CURRENT_TIMESTAMP;

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_incidents_date_type ON crime_incidents(incident_date, crime_type);
CREATE INDEX IF NOT EXISTS idx_routes_risk_distance ON routes(risk_score, distance_km);
CREATE INDEX IF NOT EXISTS idx_areas_risk_province ON areas(risk_level, province);

-- Show table creation summary
SELECT 
    'Database Setup Complete' as status,
    COUNT(*) as tables_created
FROM information_schema.tables 
WHERE table_schema = 'spectre_analytica' 
AND table_type = 'BASE TABLE';

