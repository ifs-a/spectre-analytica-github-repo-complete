# Troubleshooting Guide - Spectre Analytica

This guide helps resolve common issues encountered during deployment and operation of the Spectre Analytica platform.

## 🚨 Common Deployment Issues

### 1. CloudFormation Stack Creation Failed

#### **Issue**: Stack creation fails with permission errors
```
User: arn:aws:iam::123456789012:user/username is not authorized to perform: iam:CreateRole
```

**Solution**:
```bash
# Ensure your AWS user has the required permissions
aws iam attach-user-policy --user-name YOUR_USERNAME --policy-arn arn:aws:iam::aws:policy/PowerUserAccess
aws iam attach-user-policy --user-name YOUR_USERNAME --policy-arn arn:aws:iam::aws:policy/IAMFullAccess
```

#### **Issue**: Key pair not found
```
The key pair 'my-key' does not exist
```

**Solution**:
```bash
# Create the key pair
aws ec2 create-key-pair --key-name my-key --query 'KeyMaterial' --output text > my-key.pem
chmod 400 my-key.pem

# Or use existing key pair name
KEY_PAIR_NAME=existing-key ./scripts/deploy.sh
```

#### **Issue**: Database password parameter not found
```
Parameter /spectre-analytica/database/password not found
```

**Solution**:
```bash
# Set the database password in Parameter Store
aws ssm put-parameter \
    --name "/spectre-analytica/database/password" \
    --value "YourSecurePassword123!" \
    --type "SecureString"
```

### 2. EC2 Instance Issues

#### **Issue**: Instance fails to start or health checks fail
**Symptoms**: Auto Scaling Group shows unhealthy instances

**Diagnosis**:
```bash
# Check instance logs
aws logs get-log-events \
    --log-group-name /aws/ec2/spectre-analytica \
    --log-stream-name INSTANCE_ID/cloud-init-output.log

# SSH to instance for debugging
ssh -i your-key.pem ec2-user@INSTANCE_IP
```

**Common Solutions**:
```bash
# Check if services are running
sudo systemctl status nginx
sudo systemctl status spectre-backend

# Check application logs
sudo tail -f /var/log/spectre-backend.log
sudo tail -f /var/log/nginx/error.log

# Restart services
sudo systemctl restart nginx
sudo systemctl restart spectre-backend
```

#### **Issue**: Application not accessible via Load Balancer
**Symptoms**: Load Balancer returns 502/503 errors

**Solution**:
```bash
# Check target group health
aws elbv2 describe-target-health --target-group-arn YOUR_TARGET_GROUP_ARN

# Verify security groups allow traffic
aws ec2 describe-security-groups --group-ids sg-xxxxxxxxx

# Test direct instance access
curl http://INSTANCE_IP/api/health
```

### 3. Database Connection Issues

#### **Issue**: Backend cannot connect to RDS
```
mysql.connector.errors.DatabaseError: 2003 (HY000): Can't connect to MySQL server
```

**Diagnosis**:
```bash
# Test database connectivity from EC2 instance
mysql -h RDS_ENDPOINT -u spectreuser -p

# Check security groups
aws rds describe-db-instances --db-instance-identifier spectre-db
```

**Solutions**:
```bash
# Verify database security group allows connections from EC2
aws ec2 authorize-security-group-ingress \
    --group-id DB_SECURITY_GROUP_ID \
    --protocol tcp \
    --port 3306 \
    --source-group EC2_SECURITY_GROUP_ID

# Check database status
aws rds describe-db-instances --db-instance-identifier spectre-db --query 'DBInstances[0].DBInstanceStatus'
```

#### **Issue**: Database schema not applied
**Symptoms**: Application returns database errors about missing tables

**Solution**:
```bash
# SSH to EC2 instance and apply schema manually
ssh -i your-key.pem ec2-user@INSTANCE_IP
mysql -h RDS_ENDPOINT -u spectreuser -p spectreanalytica < /opt/spectre-analytica/database/schema.sql
```

## 🔧 Application Issues

### 1. Frontend Issues

#### **Issue**: Cesium 3D map not loading
**Symptoms**: Map shows blank or error messages

**Solutions**:
```javascript
// Check browser console for errors
// Verify Cesium Ion token is valid
// Update token in environment variables

// Test token validity
fetch('https://api.cesium.com/v1/assets/1/endpoint', {
    headers: {
        'Authorization': 'Bearer YOUR_TOKEN'
    }
})
```

#### **Issue**: API calls failing with CORS errors
**Symptoms**: Browser console shows CORS policy errors

**Solution**:
```python
# Update backend CORS configuration in main.py
from flask_cors import CORS

app = Flask(__name__)
CORS(app, origins=['http://your-domain.com', 'https://your-domain.com'])
```

### 2. Backend Issues

#### **Issue**: Flask application crashes on startup
**Symptoms**: 500 errors, application logs show Python errors

**Diagnosis**:
```bash
# Check application logs
sudo tail -f /var/log/spectre-backend.log

# Test application manually
cd /opt/spectre-analytica/backend
python main.py
```

**Common Solutions**:
```bash
# Install missing dependencies
pip install -r requirements.txt

# Check environment variables
cat .env

# Verify database connection
python -c "import mysql.connector; print('MySQL connector available')"
```

#### **Issue**: API endpoints returning 404 errors
**Symptoms**: Frontend cannot reach backend APIs

**Solution**:
```bash
# Verify nginx configuration
sudo nginx -t
sudo systemctl reload nginx

# Check if backend is running on correct port
sudo netstat -tlnp | grep :5000

# Test API directly
curl http://localhost:5000/api/health
```

## 🌐 Network and Security Issues

### 1. SSL/HTTPS Issues

#### **Issue**: SSL certificate not working
**Symptoms**: Browser shows "Not Secure" or certificate errors

**Solution**:
```bash
# Request new certificate
aws acm request-certificate \
    --domain-name your-domain.com \
    --validation-method DNS

# Update Load Balancer listener
aws elbv2 modify-listener \
    --listener-arn LISTENER_ARN \
    --certificates CertificateArn=CERTIFICATE_ARN
```

### 2. DNS Issues

#### **Issue**: Domain not resolving to Load Balancer
**Symptoms**: Domain shows "This site can't be reached"

**Solution**:
```bash
# Check DNS configuration
nslookup your-domain.com

# Update DNS records to point to Load Balancer
# CNAME: your-domain.com -> ALB_DNS_NAME

# Verify Load Balancer DNS
aws elbv2 describe-load-balancers --names spectre-analytica-alb
```

## 📊 Performance Issues

### 1. Slow Application Response

#### **Issue**: Application loads slowly or times out
**Symptoms**: High response times, user complaints

**Diagnosis**:
```bash
# Check CloudWatch metrics
aws cloudwatch get-metric-statistics \
    --namespace AWS/ApplicationELB \
    --metric-name TargetResponseTime \
    --dimensions Name=LoadBalancer,Value=ALB_FULL_NAME \
    --start-time 2023-01-01T00:00:00Z \
    --end-time 2023-01-01T23:59:59Z \
    --period 300 \
    --statistics Average
```

**Solutions**:
```bash
# Scale up instances
aws autoscaling update-auto-scaling-group \
    --auto-scaling-group-name spectre-analytica-asg \
    --desired-capacity 3

# Upgrade instance type
# Update launch template with larger instance type
# Update Auto Scaling Group to use new template
```

### 2. Database Performance Issues

#### **Issue**: Slow database queries
**Symptoms**: API responses take several seconds

**Solutions**:
```sql
-- Add database indexes
CREATE INDEX idx_crime_incidents_date ON crime_incidents(incident_date);
CREATE INDEX idx_crime_incidents_location ON crime_incidents(latitude, longitude);
CREATE INDEX idx_routes_created ON routes(created_at);

-- Optimize queries
EXPLAIN SELECT * FROM crime_incidents WHERE incident_date > '2023-01-01';
```

```bash
# Upgrade RDS instance class
aws rds modify-db-instance \
    --db-instance-identifier spectre-db \
    --db-instance-class db.t3.small \
    --apply-immediately
```

## 🔍 Monitoring and Debugging

### 1. CloudWatch Logs

#### **Access Application Logs**:
```bash
# Backend application logs
aws logs get-log-events \
    --log-group-name /aws/ec2/spectre-analytica \
    --log-stream-name INSTANCE_ID/backend/app.log

# Nginx access logs
aws logs get-log-events \
    --log-group-name /aws/ec2/spectre-analytica \
    --log-stream-name INSTANCE_ID/nginx/access.log

# System logs
aws logs get-log-events \
    --log-group-name /aws/ec2/spectre-analytica \
    --log-stream-name INSTANCE_ID/cloud-init-output.log
```

### 2. Health Check Endpoints

#### **Test Application Health**:
```bash
# Application health
curl http://your-domain.com/api/health

# Database connectivity
curl http://your-domain.com/api/dashboard-stats

# Frontend accessibility
curl -I http://your-domain.com/
```

### 3. Performance Monitoring

#### **Key Metrics to Monitor**:
```bash
# CPU utilization
aws cloudwatch get-metric-statistics \
    --namespace AWS/EC2 \
    --metric-name CPUUtilization \
    --dimensions Name=AutoScalingGroupName,Value=spectre-analytica-asg

# Memory utilization
aws cloudwatch get-metric-statistics \
    --namespace CWAgent \
    --metric-name mem_used_percent

# Database connections
aws cloudwatch get-metric-statistics \
    --namespace AWS/RDS \
    --metric-name DatabaseConnections \
    --dimensions Name=DBInstanceIdentifier,Value=spectre-db
```

## 🆘 Emergency Procedures

### 1. Application Rollback

#### **Rollback CloudFormation Stack**:
```bash
# Cancel ongoing update
aws cloudformation cancel-update-stack --stack-name spectre-analytica-prod

# Rollback to previous version
aws cloudformation continue-update-rollback --stack-name spectre-analytica-prod
```

#### **Rollback Application Code**:
```bash
# SSH to instances and rollback
ssh -i your-key.pem ec2-user@INSTANCE_IP
cd /opt/spectre-analytica
git checkout previous-working-commit
sudo systemctl restart spectre-backend
```

### 2. Database Recovery

#### **Restore from Backup**:
```bash
# List available snapshots
aws rds describe-db-snapshots --db-instance-identifier spectre-db

# Restore from snapshot
aws rds restore-db-instance-from-db-snapshot \
    --db-instance-identifier spectre-db-restored \
    --db-snapshot-identifier snapshot-id
```

### 3. Scale Down for Cost Control

#### **Reduce Infrastructure Costs**:
```bash
# Scale down Auto Scaling Group
aws autoscaling update-auto-scaling-group \
    --auto-scaling-group-name spectre-analytica-asg \
    --min-size 0 \
    --desired-capacity 0

# Stop RDS instance (if not needed)
aws rds stop-db-instance --db-instance-identifier spectre-db
```

## 📞 Getting Help

### 1. Log Collection Script
```bash
#!/bin/bash
# collect-logs.sh - Gather diagnostic information

echo "=== System Information ===" > diagnostic.log
uname -a >> diagnostic.log
date >> diagnostic.log

echo "=== Service Status ===" >> diagnostic.log
systemctl status nginx >> diagnostic.log
systemctl status spectre-backend >> diagnostic.log

echo "=== Application Logs ===" >> diagnostic.log
tail -100 /var/log/spectre-backend.log >> diagnostic.log

echo "=== Nginx Logs ===" >> diagnostic.log
tail -100 /var/log/nginx/error.log >> diagnostic.log

echo "=== Network Configuration ===" >> diagnostic.log
netstat -tlnp >> diagnostic.log

echo "Diagnostic information saved to diagnostic.log"
```

### 2. Support Channels
- **GitHub Issues**: Create detailed issue reports
- **AWS Support**: For infrastructure-related problems
- **Community Forums**: For general questions and discussions

### 3. Escalation Process
1. Check this troubleshooting guide
2. Review CloudWatch logs and metrics
3. Test individual components
4. Create GitHub issue with diagnostic information
5. Contact AWS support for infrastructure issues

---

This troubleshooting guide covers the most common issues. For additional help, please create a GitHub issue with detailed error messages and diagnostic information.

