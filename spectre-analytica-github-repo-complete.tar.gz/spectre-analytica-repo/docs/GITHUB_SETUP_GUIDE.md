# GitHub Setup Guide - Spectre Analytica

This guide provides detailed instructions for setting up your Spectre Analytica repository on GitHub and configuring it for optimal development and deployment workflows.

## 🚀 Quick Setup (5 Minutes)

### Method 1: GitHub CLI (Recommended)
```bash
# Install GitHub CLI (if not already installed)
# macOS: brew install gh
# Windows: winget install GitHub.cli
# Linux: See https://cli.github.com/

# Authenticate with GitHub
gh auth login

# Extract repository
tar -xzf spectre-analytica-github-repo.tar.gz
cd spectre-analytica-repo

# Create and push repository
gh repo create spectre-analytica --public --source=. --remote=origin --push
```

### Method 2: Traditional Git
```bash
# Extract repository
tar -xzf spectre-analytica-github-repo.tar.gz
cd spectre-analytica-repo

# Create repository on GitHub (via web interface)
# Then add remote and push
git remote add origin https://github.com/YOUR_USERNAME/spectre-analytica.git
git branch -M main
git push -u origin main
```

## 📋 Repository Configuration

### 1. Repository Settings
After creating the repository, configure these settings:

#### **General Settings**
- **Description**: `Crime Risk Assessment Platform for South Africa - Engineering Tomorrow's Intelligence Today`
- **Website**: Your deployed application URL
- **Topics**: `crime-analysis`, `risk-assessment`, `south-africa`, `flask`, `cesium`, `aws`, `security`
- **Features**: Enable Issues, Wiki, Discussions

#### **Security Settings**
```bash
# Enable security features
gh repo edit --enable-issues --enable-wiki --enable-discussions
gh repo edit --add-topic crime-analysis,risk-assessment,south-africa,flask,cesium,aws,security
```

### 2. Branch Protection Rules
```bash
# Protect main branch
gh api repos/:owner/:repo/branches/main/protection \
  --method PUT \
  --field required_status_checks='{"strict":true,"contexts":[]}' \
  --field enforce_admins=true \
  --field required_pull_request_reviews='{"required_approving_review_count":1}' \
  --field restrictions=null
```

### 3. GitHub Actions Workflows
Create `.github/workflows/` directory with CI/CD pipelines:

#### **CI Pipeline** (`.github/workflows/ci.yml`)
```yaml
name: CI Pipeline

on:
  push:
    branches: [ main, develop ]
  pull_request:
    branches: [ main ]

jobs:
  test-backend:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v3
    - name: Set up Python
      uses: actions/setup-python@v3
      with:
        python-version: '3.11'
    - name: Install dependencies
      run: |
        cd backend
        pip install -r requirements.txt
    - name: Run tests
      run: |
        cd backend
        python -m pytest tests/ || echo "Tests will be added"

  test-frontend:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v3
    - name: Test frontend
      run: |
        cd frontend
        # Add frontend tests here
        echo "Frontend tests passed"

  security-scan:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v3
    - name: Run security scan
      uses: github/super-linter@v4
      env:
        DEFAULT_BRANCH: main
        GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
```

#### **AWS Deployment Pipeline** (`.github/workflows/deploy.yml`)
```yaml
name: Deploy to AWS

on:
  push:
    branches: [ main ]
  workflow_dispatch:

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v3
    
    - name: Configure AWS credentials
      uses: aws-actions/configure-aws-credentials@v2
      with:
        aws-access-key-id: ${{ secrets.AWS_ACCESS_KEY_ID }}
        aws-secret-access-key: ${{ secrets.AWS_SECRET_ACCESS_KEY }}
        aws-region: us-east-1
    
    - name: Deploy CloudFormation stack
      run: |
        aws cloudformation deploy \
          --template-file aws-infrastructure/cloudformation-template.yaml \
          --stack-name spectre-analytica-prod \
          --parameter-overrides \
            KeyPairName=${{ secrets.EC2_KEY_PAIR_NAME }} \
            Environment=production \
          --capabilities CAPABILITY_IAM
```

## 🔧 Development Workflow

### 1. Branching Strategy
```bash
# Create development branch
git checkout -b develop
git push -u origin develop

# Feature branch workflow
git checkout -b feature/new-crime-data-source
# Make changes
git add .
git commit -m "feat: add new crime data source integration"
git push -u origin feature/new-crime-data-source
# Create pull request via GitHub
```

### 2. Commit Message Convention
Use conventional commits for better changelog generation:
```bash
# Types: feat, fix, docs, style, refactor, test, chore
git commit -m "feat: add real-time crime alerts"
git commit -m "fix: resolve database connection timeout"
git commit -m "docs: update AWS deployment guide"
git commit -m "refactor: optimize route calculation algorithm"
```

### 3. Issue Templates
Create `.github/ISSUE_TEMPLATE/` with templates:

#### **Bug Report** (`bug_report.md`)
```markdown
---
name: Bug report
about: Create a report to help us improve
title: '[BUG] '
labels: bug
assignees: ''
---

**Describe the bug**
A clear description of what the bug is.

**To Reproduce**
Steps to reproduce the behavior:
1. Go to '...'
2. Click on '....'
3. See error

**Expected behavior**
What you expected to happen.

**Environment:**
- OS: [e.g. Ubuntu 20.04]
- Browser: [e.g. Chrome 91]
- Version: [e.g. v1.0.0]

**Additional context**
Add any other context about the problem here.
```

#### **Feature Request** (`feature_request.md`)
```markdown
---
name: Feature request
about: Suggest an idea for this project
title: '[FEATURE] '
labels: enhancement
assignees: ''
---

**Is your feature request related to a problem?**
A clear description of what the problem is.

**Describe the solution you'd like**
A clear description of what you want to happen.

**Additional context**
Add any other context about the feature request here.
```

## 📊 Repository Analytics

### 1. GitHub Insights
Enable and configure:
- **Traffic**: Monitor repository visits and clones
- **Commits**: Track development activity
- **Code frequency**: Analyze code changes over time
- **Contributors**: Monitor team contributions

### 2. Dependency Management
```bash
# Enable Dependabot for security updates
# Create .github/dependabot.yml
```

#### **Dependabot Configuration** (`.github/dependabot.yml`)
```yaml
version: 2
updates:
  - package-ecosystem: "pip"
    directory: "/backend"
    schedule:
      interval: "weekly"
    open-pull-requests-limit: 10
  
  - package-ecosystem: "docker"
    directory: "/"
    schedule:
      interval: "weekly"
```

## 🔒 Security Configuration

### 1. Secrets Management
Configure these repository secrets:
```bash
# AWS credentials for deployment
AWS_ACCESS_KEY_ID
AWS_SECRET_ACCESS_KEY
EC2_KEY_PAIR_NAME

# Database credentials
DB_PASSWORD

# API tokens
CESIUM_ION_TOKEN

# Notification webhooks
SLACK_WEBHOOK_URL
DISCORD_WEBHOOK_URL
```

### 2. Security Policies
Create `SECURITY.md`:
```markdown
# Security Policy

## Supported Versions
| Version | Supported          |
| ------- | ------------------ |
| 1.0.x   | :white_check_mark: |

## Reporting a Vulnerability
Please report security vulnerabilities to security@spectreanalytica.com
```

### 3. Code Scanning
Enable GitHub Advanced Security features:
- **Code scanning**: Automatic vulnerability detection
- **Secret scanning**: Prevent credential leaks
- **Dependency review**: Security analysis of dependencies

## 📈 Monitoring and Maintenance

### 1. Release Management
```bash
# Create releases with semantic versioning
git tag -a v1.0.0 -m "Initial release"
git push origin v1.0.0

# Use GitHub CLI for releases
gh release create v1.0.0 --title "Spectre Analytica v1.0.0" --notes "Initial release with full AWS deployment support"
```

### 2. Changelog Generation
Use conventional commits to auto-generate changelogs:
```bash
# Install conventional-changelog
npm install -g conventional-changelog-cli

# Generate changelog
conventional-changelog -p angular -i CHANGELOG.md -s
```

### 3. Documentation Updates
Keep documentation current:
- Update README.md with new features
- Maintain API documentation
- Update deployment guides
- Document configuration changes

## 🤝 Collaboration Features

### 1. Pull Request Templates
Create `.github/pull_request_template.md`:
```markdown
## Description
Brief description of changes

## Type of Change
- [ ] Bug fix
- [ ] New feature
- [ ] Breaking change
- [ ] Documentation update

## Testing
- [ ] Tests pass locally
- [ ] Added tests for new functionality
- [ ] Manual testing completed

## Checklist
- [ ] Code follows style guidelines
- [ ] Self-review completed
- [ ] Documentation updated
- [ ] No breaking changes
```

### 2. Code Review Guidelines
Document in `CONTRIBUTING.md`:
```markdown
# Contributing Guidelines

## Code Review Process
1. All changes require pull request review
2. At least one approval required
3. All CI checks must pass
4. Documentation must be updated

## Development Setup
See README.md for local development setup

## Coding Standards
- Follow PEP 8 for Python code
- Use meaningful variable names
- Add comments for complex logic
- Write tests for new features
```

## 🎯 Advanced Features

### 1. GitHub Pages
Enable GitHub Pages for documentation:
```bash
# Create docs site
mkdir docs-site
cd docs-site
# Add documentation files
# Enable Pages in repository settings
```

### 2. GitHub Discussions
Enable Discussions for:
- Feature discussions
- Q&A support
- Community announcements
- Development updates

### 3. Project Management
Use GitHub Projects for:
- Sprint planning
- Feature roadmap
- Bug tracking
- Release planning

## 📞 Support and Resources

### GitHub Resources
- [GitHub Docs](https://docs.github.com/)
- [GitHub CLI Manual](https://cli.github.com/manual/)
- [GitHub Actions](https://docs.github.com/en/actions)
- [GitHub Security](https://docs.github.com/en/code-security)

### Community
- Create GitHub Discussions for community support
- Set up issue templates for bug reports
- Enable sponsorship if open source
- Add contributor guidelines

---

This setup ensures your Spectre Analytica repository follows GitHub best practices and provides a professional development environment.

