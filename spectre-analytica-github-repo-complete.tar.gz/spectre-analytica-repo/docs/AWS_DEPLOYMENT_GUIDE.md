# AWS Deployment Guide - Spectre Analytica

This guide provides step-by-step instructions for deploying Spectre Analytica on Amazon Web Services (AWS).

## 🏗️ Architecture Overview

The AWS deployment consists of:
- **Application Load Balancer** - Traffic distribution and SSL termination
- **Auto Scaling Group** - Automatic scaling based on demand
- **EC2 Instances** - Application servers running the platform
- **RDS MySQL** - Managed database service
- **S3 Bucket** - Static assets and backup storage
- **CloudWatch** - Monitoring and logging
- **VPC** - Isolated network environment

## 📋 Prerequisites

### AWS Account Setup
1. **AWS Account** with appropriate permissions
2. **AWS CLI** installed and configured
3. **EC2 Key Pair** for SSH access
4. **Domain name** (optional, for custom domain)

### Required AWS Permissions
```json
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "ec2:*",
                "rds:*",
                "elbv2:*",
                "autoscaling:*",
                "cloudformation:*",
                "iam:*",
                "s3:*",
                "ssm:*",
                "cloudwatch:*",
                "logs:*"
            ],
            "Resource": "*"
        }
    ]
}
```

## 🚀 Deployment Methods

### Method 1: CloudFormation (Recommended)

#### Step 1: Prepare Parameters
Create a parameters file `parameters.json`:
```json
[
    {
        "ParameterKey": "Environment",
        "ParameterValue": "production"
    },
    {
        "ParameterKey": "InstanceType",
        "ParameterValue": "t3.medium"
    },
    {
        "ParameterKey": "DBInstanceClass",
        "ParameterValue": "db.t3.micro"
    },
    {
        "ParameterKey": "KeyPairName",
        "ParameterValue": "your-key-pair-name"
    },
    {
        "ParameterKey": "DomainName",
        "ParameterValue": "spectreanalytica.com"
    }
]
```

#### Step 2: Set Database Password
```bash
aws ssm put-parameter \
    --name "/spectre-analytica/database/password" \
    --value "YourSecurePassword123!" \
    --type "SecureString" \
    --description "Database password for Spectre Analytica"
```

#### Step 3: Deploy Stack
```bash
aws cloudformation create-stack \
    --stack-name spectre-analytica-production \
    --template-body file://aws-infrastructure/cloudformation-template.yaml \
    --parameters file://parameters.json \
    --capabilities CAPABILITY_IAM \
    --region us-east-1
```

#### Step 4: Monitor Deployment
```bash
aws cloudformation describe-stacks \
    --stack-name spectre-analytica-production \
    --query 'Stacks[0].StackStatus'
```

#### Step 5: Get Outputs
```bash
aws cloudformation describe-stacks \
    --stack-name spectre-analytica-production \
    --query 'Stacks[0].Outputs'
```

### Method 2: Terraform

#### Step 1: Initialize Terraform
```bash
cd aws-infrastructure/terraform
terraform init
```

#### Step 2: Configure Variables
Create `terraform.tfvars`:
```hcl
aws_region = "us-east-1"
environment = "production"
instance_type = "t3.medium"
db_instance_class = "db.t3.micro"
key_pair_name = "your-key-pair-name"
domain_name = "spectreanalytica.com"
db_password = "YourSecurePassword123!"
```

#### Step 3: Plan and Apply
```bash
terraform plan
terraform apply
```

#### Step 4: Get Outputs
```bash
terraform output
```

### Method 3: Docker + ECS

#### Step 1: Create ECR Repositories
```bash
aws ecr create-repository --repository-name spectre-frontend
aws ecr create-repository --repository-name spectre-backend
```

#### Step 2: Build and Push Images
```bash
# Get login token
aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin YOUR_ACCOUNT.dkr.ecr.us-east-1.amazonaws.com

# Build images
docker-compose -f aws-infrastructure/docker-compose.aws.yml build

# Tag images
docker tag spectre-analytica_frontend:latest YOUR_ACCOUNT.dkr.ecr.us-east-1.amazonaws.com/spectre-frontend:latest
docker tag spectre-analytica_backend:latest YOUR_ACCOUNT.dkr.ecr.us-east-1.amazonaws.com/spectre-backend:latest

# Push images
docker push YOUR_ACCOUNT.dkr.ecr.us-east-1.amazonaws.com/spectre-frontend:latest
docker push YOUR_ACCOUNT.dkr.ecr.us-east-1.amazonaws.com/spectre-backend:latest
```

#### Step 3: Create ECS Cluster
```bash
aws ecs create-cluster --cluster-name spectre-analytica
```

#### Step 4: Create Task Definition
```bash
aws ecs register-task-definition --cli-input-json file://ecs-task-definition.json
```

#### Step 5: Create Service
```bash
aws ecs create-service \
    --cluster spectre-analytica \
    --service-name spectre-service \
    --task-definition spectre-analytica:1 \
    --desired-count 2
```

## 🔧 Post-Deployment Configuration

### 1. Database Setup
The database schema is automatically applied during deployment. To manually apply:
```bash
# SSH to an EC2 instance
ssh -i your-key.pem ec2-user@YOUR_INSTANCE_IP

# Apply schema
mysql -h YOUR_RDS_ENDPOINT -u spectreuser -p spectreanalytica < /opt/spectre-analytica/database/schema.sql
```

### 2. SSL Certificate (Optional)
For HTTPS support, request an SSL certificate:
```bash
aws acm request-certificate \
    --domain-name spectreanalytica.com \
    --domain-name *.spectreanalytica.com \
    --validation-method DNS
```

### 3. Domain Configuration
Update your DNS records to point to the Load Balancer:
```
Type: CNAME
Name: spectreanalytica.com
Value: YOUR_ALB_DNS_NAME
```

### 4. CloudWatch Alarms
Set up additional monitoring:
```bash
aws cloudwatch put-metric-alarm \
    --alarm-name "SpectrAnalytica-HighCPU" \
    --alarm-description "High CPU utilization" \
    --metric-name CPUUtilization \
    --namespace AWS/EC2 \
    --statistic Average \
    --period 300 \
    --threshold 80 \
    --comparison-operator GreaterThanThreshold \
    --evaluation-periods 2
```

## 📊 Monitoring and Maintenance

### CloudWatch Dashboards
Create a custom dashboard:
```bash
aws cloudwatch put-dashboard \
    --dashboard-name "SpectrAnalytica" \
    --dashboard-body file://cloudwatch-dashboard.json
```

### Log Groups
Monitor application logs:
- `/aws/ec2/spectre-analytica` - Application logs
- `/aws/rds/instance/spectre-db/error` - Database logs
- `/aws/elasticloadbalancing/application/spectre-alb` - Load balancer logs

### Backup Strategy
Automated backups are configured for:
- **RDS**: 7-day retention with point-in-time recovery
- **Application Data**: Daily S3 backups via cron job
- **Configuration**: Infrastructure as Code in Git

## 🔒 Security Best Practices

### Network Security
- VPC with private subnets for database
- Security groups with minimal required access
- No direct internet access to database

### Data Security
- Encrypted RDS storage
- Encrypted S3 buckets
- SSL/TLS for all communications

### Access Control
- IAM roles with least privilege
- No hardcoded credentials
- Secrets stored in AWS Systems Manager

## 💰 Cost Optimization

### Instance Sizing
- Start with `t3.micro` for development
- Use `t3.medium` for production
- Monitor and adjust based on usage

### Reserved Instances
Consider Reserved Instances for:
- EC2 instances (1-3 year terms)
- RDS instances (1-3 year terms)

### Auto Scaling
Configure scaling policies:
```bash
aws autoscaling put-scaling-policy \
    --auto-scaling-group-name spectre-analytica-asg \
    --policy-name scale-up \
    --scaling-adjustment 1 \
    --adjustment-type ChangeInCapacity
```

## 🚨 Troubleshooting

### Common Issues

#### 1. Database Connection Failed
```bash
# Check security groups
aws ec2 describe-security-groups --group-ids sg-xxxxxxxxx

# Test connection
mysql -h YOUR_RDS_ENDPOINT -u spectreuser -p
```

#### 2. Application Not Starting
```bash
# Check logs
aws logs get-log-events \
    --log-group-name /aws/ec2/spectre-analytica \
    --log-stream-name YOUR_INSTANCE_ID/backend/app.log
```

#### 3. Load Balancer Health Checks Failing
```bash
# Check target group health
aws elbv2 describe-target-health \
    --target-group-arn YOUR_TARGET_GROUP_ARN
```

### Health Check Endpoints
- Application: `http://YOUR_ALB_DNS/api/health`
- Database: Check RDS console
- Load Balancer: Check target group health

## 📞 Support

For deployment issues:
1. Check CloudFormation events for stack creation errors
2. Review CloudWatch logs for application errors
3. Verify security group and network ACL configurations
4. Ensure all required parameters are correctly set

## 🔄 Updates and Rollbacks

### Application Updates
```bash
# Update Auto Scaling Group with new launch template
aws autoscaling update-auto-scaling-group \
    --auto-scaling-group-name spectre-analytica-asg \
    --launch-template LaunchTemplateId=lt-xxxxxxxxx,Version='$Latest'
```

### Database Updates
```bash
# Apply schema changes
mysql -h YOUR_RDS_ENDPOINT -u spectreuser -p spectreanalytica < new-schema-changes.sql
```

### Rollback Strategy
```bash
# Rollback CloudFormation stack
aws cloudformation cancel-update-stack --stack-name spectre-analytica-production

# Or update with previous template
aws cloudformation update-stack \
    --stack-name spectre-analytica-production \
    --template-body file://previous-template.yaml
```

---

This deployment guide ensures a robust, scalable, and secure deployment of Spectre Analytica on AWS infrastructure.

