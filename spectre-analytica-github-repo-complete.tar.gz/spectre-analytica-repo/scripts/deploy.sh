#!/bin/bash

# Spectre Analytica Deployment Script
# This script automates the deployment process for AWS

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
STACK_NAME="spectre-analytica-production"
REGION="us-east-1"
ENVIRONMENT="production"

# Functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

check_prerequisites() {
    log_info "Checking prerequisites..."
    
    # Check AWS CLI
    if ! command -v aws &> /dev/null; then
        log_error "AWS CLI is not installed. Please install it first."
        exit 1
    fi
    
    # Check AWS credentials
    if ! aws sts get-caller-identity &> /dev/null; then
        log_error "AWS credentials not configured. Please run 'aws configure'."
        exit 1
    fi
    
    # Check if key pair exists
    if [ -z "$KEY_PAIR_NAME" ]; then
        log_error "KEY_PAIR_NAME environment variable is not set."
        exit 1
    fi
    
    if ! aws ec2 describe-key-pairs --key-names "$KEY_PAIR_NAME" &> /dev/null; then
        log_error "Key pair '$KEY_PAIR_NAME' does not exist."
        exit 1
    fi
    
    log_success "Prerequisites check passed"
}

set_database_password() {
    log_info "Setting database password in AWS Systems Manager..."
    
    if [ -z "$DB_PASSWORD" ]; then
        log_warning "DB_PASSWORD not set. Generating random password..."
        DB_PASSWORD=$(openssl rand -base64 32)
        log_info "Generated password: $DB_PASSWORD"
    fi
    
    aws ssm put-parameter \
        --name "/spectre-analytica/database/password" \
        --value "$DB_PASSWORD" \
        --type "SecureString" \
        --description "Database password for Spectre Analytica" \
        --overwrite \
        --region "$REGION"
    
    log_success "Database password set in Parameter Store"
}

deploy_infrastructure() {
    log_info "Deploying infrastructure with CloudFormation..."
    
    # Create parameters file
    cat > /tmp/parameters.json << EOF
[
    {
        "ParameterKey": "Environment",
        "ParameterValue": "$ENVIRONMENT"
    },
    {
        "ParameterKey": "InstanceType",
        "ParameterValue": "${INSTANCE_TYPE:-t3.medium}"
    },
    {
        "ParameterKey": "DBInstanceClass",
        "ParameterValue": "${DB_INSTANCE_CLASS:-db.t3.micro}"
    },
    {
        "ParameterKey": "KeyPairName",
        "ParameterValue": "$KEY_PAIR_NAME"
    },
    {
        "ParameterKey": "DomainName",
        "ParameterValue": "${DOMAIN_NAME:-spectreanalytica.com}"
    }
]
EOF
    
    # Check if stack exists
    if aws cloudformation describe-stacks --stack-name "$STACK_NAME" --region "$REGION" &> /dev/null; then
        log_info "Stack exists. Updating..."
        aws cloudformation update-stack \
            --stack-name "$STACK_NAME" \
            --template-body file://aws-infrastructure/cloudformation-template.yaml \
            --parameters file:///tmp/parameters.json \
            --capabilities CAPABILITY_IAM \
            --region "$REGION"
    else
        log_info "Creating new stack..."
        aws cloudformation create-stack \
            --stack-name "$STACK_NAME" \
            --template-body file://aws-infrastructure/cloudformation-template.yaml \
            --parameters file:///tmp/parameters.json \
            --capabilities CAPABILITY_IAM \
            --region "$REGION"
    fi
    
    log_info "Waiting for stack deployment to complete..."
    aws cloudformation wait stack-create-complete \
        --stack-name "$STACK_NAME" \
        --region "$REGION" || \
    aws cloudformation wait stack-update-complete \
        --stack-name "$STACK_NAME" \
        --region "$REGION"
    
    log_success "Infrastructure deployment completed"
}

get_outputs() {
    log_info "Retrieving stack outputs..."
    
    OUTPUTS=$(aws cloudformation describe-stacks \
        --stack-name "$STACK_NAME" \
        --region "$REGION" \
        --query 'Stacks[0].Outputs' \
        --output json)
    
    ALB_DNS=$(echo "$OUTPUTS" | jq -r '.[] | select(.OutputKey=="LoadBalancerDNS") | .OutputValue')
    DB_ENDPOINT=$(echo "$OUTPUTS" | jq -r '.[] | select(.OutputKey=="DatabaseEndpoint") | .OutputValue')
    S3_BUCKET=$(echo "$OUTPUTS" | jq -r '.[] | select(.OutputKey=="S3BucketName") | .OutputValue')
    
    log_success "Application URL: http://$ALB_DNS"
    log_success "Database Endpoint: $DB_ENDPOINT"
    log_success "S3 Bucket: $S3_BUCKET"
}

verify_deployment() {
    log_info "Verifying deployment..."
    
    # Wait for application to be ready
    sleep 60
    
    # Check health endpoint
    if curl -f "http://$ALB_DNS/api/health" &> /dev/null; then
        log_success "Application health check passed"
    else
        log_warning "Application health check failed. It may still be starting up."
    fi
    
    # Check if frontend is accessible
    if curl -f "http://$ALB_DNS/" &> /dev/null; then
        log_success "Frontend is accessible"
    else
        log_warning "Frontend is not accessible yet"
    fi
}

cleanup() {
    log_info "Cleaning up temporary files..."
    rm -f /tmp/parameters.json
}

show_usage() {
    echo "Usage: $0 [OPTIONS]"
    echo ""
    echo "Options:"
    echo "  -h, --help              Show this help message"
    echo "  -e, --environment ENV   Set environment (default: production)"
    echo "  -r, --region REGION     Set AWS region (default: us-east-1)"
    echo "  -s, --stack-name NAME   Set CloudFormation stack name"
    echo "  --dry-run              Show what would be deployed without executing"
    echo ""
    echo "Required Environment Variables:"
    echo "  KEY_PAIR_NAME          EC2 Key Pair name for SSH access"
    echo ""
    echo "Optional Environment Variables:"
    echo "  DB_PASSWORD            Database password (auto-generated if not set)"
    echo "  INSTANCE_TYPE          EC2 instance type (default: t3.medium)"
    echo "  DB_INSTANCE_CLASS      RDS instance class (default: db.t3.micro)"
    echo "  DOMAIN_NAME            Domain name (default: spectreanalytica.com)"
    echo ""
    echo "Example:"
    echo "  KEY_PAIR_NAME=my-key ./deploy.sh"
}

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        -h|--help)
            show_usage
            exit 0
            ;;
        -e|--environment)
            ENVIRONMENT="$2"
            shift 2
            ;;
        -r|--region)
            REGION="$2"
            shift 2
            ;;
        -s|--stack-name)
            STACK_NAME="$2"
            shift 2
            ;;
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        *)
            log_error "Unknown option: $1"
            show_usage
            exit 1
            ;;
    esac
done

# Main execution
main() {
    log_info "Starting Spectre Analytica deployment..."
    log_info "Environment: $ENVIRONMENT"
    log_info "Region: $REGION"
    log_info "Stack Name: $STACK_NAME"
    
    if [ "$DRY_RUN" = true ]; then
        log_info "DRY RUN MODE - No actual deployment will occur"
        log_info "Would deploy with the following configuration:"
        log_info "  Environment: $ENVIRONMENT"
        log_info "  Region: $REGION"
        log_info "  Stack Name: $STACK_NAME"
        log_info "  Key Pair: $KEY_PAIR_NAME"
        log_info "  Instance Type: ${INSTANCE_TYPE:-t3.medium}"
        log_info "  DB Instance Class: ${DB_INSTANCE_CLASS:-db.t3.micro}"
        log_info "  Domain: ${DOMAIN_NAME:-spectreanalytica.com}"
        exit 0
    fi
    
    check_prerequisites
    set_database_password
    deploy_infrastructure
    get_outputs
    verify_deployment
    cleanup
    
    log_success "Deployment completed successfully!"
    log_info "Access your application at: http://$ALB_DNS"
    log_info "API Health Check: http://$ALB_DNS/api/health"
    
    if [ -n "$DOMAIN_NAME" ] && [ "$DOMAIN_NAME" != "spectreanalytica.com" ]; then
        log_info "Don't forget to update your DNS records to point to: $ALB_DNS"
    fi
}

# Trap to ensure cleanup on exit
trap cleanup EXIT

# Run main function
main "$@"

