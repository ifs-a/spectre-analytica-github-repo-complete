#!/bin/bash
# Spectre Analytica EC2 Instance Setup Script

# Update system
yum update -y

# Install required packages
yum install -y python3 python3-pip git mysql nginx awscli

# Install Node.js
curl -sL https://rpm.nodesource.com/setup_18.x | bash -
yum install -y nodejs

# Create application directory
mkdir -p /opt/spectre-analytica
cd /opt/spectre-analytica

# Clone application (replace with your GitHub repository)
git clone https://github.com/YOUR_USERNAME/spectre-analytica.git .

# Setup backend
cd backend
pip3 install -r requirements.txt

# Get database password from SSM Parameter Store
DB_PASSWORD=$(aws ssm get-parameter --name /spectre-analytica/database/password --with-decryption --query Parameter.Value --output text --region ${aws_region})

# Configure environment variables
cat > .env << EOF
FLASK_ENV=production
FLASK_DEBUG=False
PORT=5000
DB_HOST=${db_endpoint}
DB_PORT=3306
DB_NAME=spectreanalytica
DB_USER=spectreuser
DB_PASSWORD=$DB_PASSWORD
CESIUM_ION_TOKEN=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiJlMjRhZWZlYi1lMThhLTRjZDgtYTRmZC04ZjI2MTQ4NjMyYTkiLCJpZCI6MzI1MzcyLCJpYXQiOjE3NTM4Mjg3MjN9.yfIU-QnXt8elq0wbB8-YSRj1bCP9VTOZKZNXZbnZG1o
AWS_REGION=${aws_region}
EOF

# Wait for database to be available
echo "Waiting for database to be available..."
while ! mysql -h ${db_endpoint} -u spectreuser -p$DB_PASSWORD -e "SELECT 1" > /dev/null 2>&1; do
    sleep 10
done

# Setup database schema
mysql -h ${db_endpoint} -u spectreuser -p$DB_PASSWORD spectreanalytica < ../database/schema.sql

# Create systemd service for backend
cat > /etc/systemd/system/spectre-backend.service << EOF
[Unit]
Description=Spectre Analytica Backend
After=network.target

[Service]
Type=simple
User=ec2-user
WorkingDirectory=/opt/spectre-analytica/backend
Environment=PATH=/usr/bin:/usr/local/bin
ExecStart=/usr/bin/python3 main.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

# Enable and start backend service
systemctl enable spectre-backend
systemctl start spectre-backend

# Configure nginx
cat > /etc/nginx/conf.d/spectre.conf << EOF
server {
    listen 80;
    server_name _;
    
    # Frontend static files
    location / {
        root /opt/spectre-analytica/frontend;
        index index.html;
        try_files \$uri \$uri/ /index.html;
    }
    
    # Backend API
    location /api/ {
        proxy_pass http://localhost:5000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
    
    # Health check endpoint
    location /health {
        proxy_pass http://localhost:5000/api/health;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
    }
    
    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header Referrer-Policy "no-referrer-when-downgrade" always;
    add_header Content-Security-Policy "default-src 'self' http: https: data: blob: 'unsafe-inline'" always;
}
EOF

# Remove default nginx configuration
rm -f /etc/nginx/conf.d/default.conf

# Enable and start nginx
systemctl enable nginx
systemctl start nginx

# Install CloudWatch agent
wget https://s3.amazonaws.com/amazoncloudwatch-agent/amazon_linux/amd64/latest/amazon-cloudwatch-agent.rpm
rpm -U ./amazon-cloudwatch-agent.rpm

# Configure CloudWatch agent
cat > /opt/aws/amazon-cloudwatch-agent/etc/amazon-cloudwatch-agent.json << EOF
{
    "logs": {
        "logs_collected": {
            "files": {
                "collect_list": [
                    {
                        "file_path": "/var/log/nginx/access.log",
                        "log_group_name": "/aws/ec2/spectre-analytica",
                        "log_stream_name": "{instance_id}/nginx/access.log"
                    },
                    {
                        "file_path": "/var/log/nginx/error.log",
                        "log_group_name": "/aws/ec2/spectre-analytica",
                        "log_stream_name": "{instance_id}/nginx/error.log"
                    },
                    {
                        "file_path": "/var/log/spectre-backend.log",
                        "log_group_name": "/aws/ec2/spectre-analytica",
                        "log_stream_name": "{instance_id}/backend/app.log"
                    }
                ]
            }
        }
    },
    "metrics": {
        "namespace": "SpectrAnalytica/EC2",
        "metrics_collected": {
            "cpu": {
                "measurement": [
                    "cpu_usage_idle",
                    "cpu_usage_iowait",
                    "cpu_usage_user",
                    "cpu_usage_system"
                ],
                "metrics_collection_interval": 60
            },
            "disk": {
                "measurement": [
                    "used_percent"
                ],
                "metrics_collection_interval": 60,
                "resources": [
                    "*"
                ]
            },
            "mem": {
                "measurement": [
                    "mem_used_percent"
                ],
                "metrics_collection_interval": 60
            }
        }
    }
}
EOF

# Start CloudWatch agent
/opt/aws/amazon-cloudwatch-agent/bin/amazon-cloudwatch-agent-ctl -a fetch-config -m ec2 -c file:/opt/aws/amazon-cloudwatch-agent/etc/amazon-cloudwatch-agent.json -s

# Create log rotation for application logs
cat > /etc/logrotate.d/spectre-analytica << EOF
/var/log/spectre-backend.log {
    daily
    missingok
    rotate 7
    compress
    delaycompress
    notifempty
    create 644 ec2-user ec2-user
    postrotate
        systemctl reload spectre-backend
    endscript
}
EOF

# Set up automatic security updates
echo "0 2 * * * root yum update -y --security" >> /etc/crontab

# Create backup script
cat > /opt/spectre-analytica/backup.sh << EOF
#!/bin/bash
DATE=\$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="/opt/spectre-analytica/backups"
mkdir -p \$BACKUP_DIR

# Database backup
mysqldump -h ${db_endpoint} -u spectreuser -p$DB_PASSWORD spectreanalytica > \$BACKUP_DIR/db_backup_\$DATE.sql

# Upload to S3 (bucket name will be provided via environment variable)
if [ ! -z "\$S3_BACKUP_BUCKET" ]; then
    aws s3 cp \$BACKUP_DIR/db_backup_\$DATE.sql s3://\$S3_BACKUP_BUCKET/backups/
fi

# Keep only last 7 days of local backups
find \$BACKUP_DIR -name "db_backup_*.sql" -mtime +7 -delete
EOF

chmod +x /opt/spectre-analytica/backup.sh

# Schedule daily backups
echo "0 3 * * * root /opt/spectre-analytica/backup.sh" >> /etc/crontab

# Signal CloudFormation that the instance is ready
/opt/aws/bin/cfn-signal -e $? --stack \${AWS::StackName} --resource AutoScalingGroup --region ${aws_region}

echo "Spectre Analytica setup completed successfully!"

