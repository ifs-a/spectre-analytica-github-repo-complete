from flask import Flask, send_from_directory, jsonify, request
from flask_cors import CORS
import mysql.connector
from mysql.connector import Error
import os
import json
from datetime import datetime, timedelta
import random
import hashlib

app = Flask(__name__, static_folder="static", static_url_path="")

# Enable CORS for all routes
CORS(app, origins="*")

# Database configuration
DB_CONFIG = {
    'host': 'localhost',
    'database': 'spectre_analytica',
    'user': 'spectre_user',
    'password': 'SpectreDB2025',
    'charset': 'utf8mb4',
    'autocommit': True
}

def get_db_connection():
    """Create and return a database connection"""
    try:
        connection = mysql.connector.connect(**DB_CONFIG)
        return connection
    except Error as e:
        print(f"Database connection error: {e}")
        return None

def execute_query(query, params=None, fetch=False):
    """Execute a database query with error handling"""
    connection = get_db_connection()
    if not connection:
        return None
    
    try:
        cursor = connection.cursor(dictionary=True)
        cursor.execute(query, params or ())
        
        if fetch:
            result = cursor.fetchall()
        else:
            result = cursor.rowcount
            
        cursor.close()
        connection.close()
        return result
    except Error as e:
        print(f"Query execution error: {e}")
        if connection:
            connection.close()
        return None

# Health check endpoint
@app.route("/api/health")
def health_check():
    # Test database connection
    connection = get_db_connection()
    db_status = "connected" if connection else "disconnected"
    if connection:
        connection.close()
    
    return jsonify({
        "status": "operational",
        "timestamp": datetime.utcnow().isoformat(),
        "service": "Spectre Analytica Backend",
        "version": "2.0.0",
        "database": db_status
    })

# Crime data endpoints
@app.route("/api/crime-data")
def get_crime_data():
    """Get crime incidents from database"""
    try:
        # Get recent crime incidents (last 30 days)
        query = """
        SELECT 
            id, incident_id, crime_type, title, description,
            latitude, longitude, location_name, address,
            province, city, suburb, severity_level,
            incident_date, incident_time, status,
            casualties, injuries, created_at
        FROM crime_incidents 
        WHERE incident_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
        ORDER BY incident_date DESC, severity_level DESC
        LIMIT 100
        """
        
        incidents = execute_query(query, fetch=True)
        
        if incidents is None:
            # Fallback to mock data if database fails
            incidents = [
                {"id": 1, "crime_type": "murder", "latitude": -26.2041, "longitude": 28.0473, "severity_level": 9, "incident_date": "2025-07-29"},
                {"id": 2, "crime_type": "carjacking", "latitude": -26.1076, "longitude": 28.0567, "severity_level": 8, "incident_date": "2025-07-29"},
                {"id": 3, "crime_type": "common_robbery", "latitude": -33.9249, "longitude": 18.4241, "severity_level": 6, "incident_date": "2025-07-28"}
            ]
        
        # Convert datetime objects to strings for JSON serialization
        for incident in incidents:
            if 'incident_date' in incident and incident['incident_date']:
                incident['incident_date'] = incident['incident_date'].strftime('%Y-%m-%d')
            if 'incident_time' in incident and incident['incident_time']:
                incident['incident_time'] = str(incident['incident_time'])
            if 'created_at' in incident and incident['created_at']:
                incident['created_at'] = incident['created_at'].isoformat()
        
        return jsonify({
            "success": True,
            "data": incidents,
            "count": len(incidents),
            "timestamp": datetime.utcnow().isoformat()
        })
        
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e),
            "timestamp": datetime.utcnow().isoformat()
        }), 500

@app.route("/api/crime-statistics")
def get_crime_statistics():
    """Get crime statistics summary"""
    try:
        # Get crime counts by type
        query = """
        SELECT 
            crime_type,
            COUNT(*) as count,
            AVG(severity_level) as avg_severity
        FROM crime_incidents 
        WHERE incident_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
        GROUP BY crime_type
        ORDER BY count DESC
        """
        
        stats = execute_query(query, fetch=True)
        
        if stats is None:
            stats = [
                {"crime_type": "murder", "count": 15, "avg_severity": 8.5},
                {"crime_type": "carjacking", "count": 23, "avg_severity": 7.8},
                {"crime_type": "common_robbery", "count": 45, "avg_severity": 6.2}
            ]
        
        # Get provincial statistics
        province_query = """
        SELECT 
            province,
            COUNT(*) as incident_count,
            AVG(severity_level) as avg_risk
        FROM crime_incidents 
        WHERE incident_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
        AND province IS NOT NULL
        GROUP BY province
        ORDER BY incident_count DESC
        """
        
        provinces = execute_query(province_query, fetch=True)
        
        if provinces is None:
            provinces = [
                {"province": "Gauteng", "incident_count": 45, "avg_risk": 7.2},
                {"province": "Western Cape", "incident_count": 32, "avg_risk": 6.8},
                {"province": "KwaZulu-Natal", "incident_count": 28, "avg_risk": 6.5}
            ]
        
        return jsonify({
            "success": True,
            "crime_types": stats,
            "provinces": provinces,
            "timestamp": datetime.utcnow().isoformat()
        })
        
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e),
            "timestamp": datetime.utcnow().isoformat()
        }), 500

@app.route("/api/areas")
def get_areas():
    """Get risk areas from database"""
    try:
        query = """
        SELECT 
            id, area_name, area_type, description,
            center_lat, center_lng, radius_km,
            province, city, suburb, risk_level,
            incident_count, police_presence, lighting_quality
        FROM areas 
        WHERE is_active = TRUE
        ORDER BY risk_level DESC, area_name
        """
        
        areas = execute_query(query, fetch=True)
        
        if areas is None:
            areas = [
                {"area_name": "Johannesburg CBD", "area_type": "high_risk", "center_lat": -26.2041, "center_lng": 28.0473, "risk_level": 8},
                {"area_name": "Sandton", "area_type": "low_risk", "center_lat": -26.1076, "center_lng": 28.0567, "risk_level": 3}
            ]
        
        return jsonify({
            "success": True,
            "data": areas,
            "count": len(areas),
            "timestamp": datetime.utcnow().isoformat()
        })
        
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e),
            "timestamp": datetime.utcnow().isoformat()
        }), 500

@app.route("/api/route-planning", methods=["POST"])
def calculate_route():
    """Calculate safe route and store in database"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['origin_address', 'destination_address', 'origin_lat', 'origin_lng', 'destination_lat', 'destination_lng']
        for field in required_fields:
            if field not in data:
                return jsonify({
                    "success": False,
                    "error": f"Missing required field: {field}"
                }), 400
        
        # Calculate route metrics (simplified calculation)
        import math
        
        lat1, lng1 = float(data['origin_lat']), float(data['origin_lng'])
        lat2, lng2 = float(data['destination_lat']), float(data['destination_lng'])
        
        # Calculate distance using Haversine formula
        R = 6371  # Earth's radius in kilometers
        dlat = math.radians(lat2 - lat1)
        dlng = math.radians(lng2 - lng1)
        a = math.sin(dlat/2)**2 + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(dlng/2)**2
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))
        distance = R * c
        
        # Estimate travel time (assuming average speed of 60 km/h)
        estimated_time = int(distance / 60 * 60)  # in minutes
        
        # Calculate risk score based on nearby incidents
        threat_radius = data.get('threat_radius_km', 10)
        risk_query = """
        SELECT COUNT(*) as threat_count, AVG(severity_level) as avg_severity
        FROM crime_incidents
        WHERE incident_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
        AND (
            (6371 * acos(cos(radians(%s)) * cos(radians(latitude)) * 
             cos(radians(longitude) - radians(%s)) + sin(radians(%s)) * 
             sin(radians(latitude)))) <= %s
            OR
            (6371 * acos(cos(radians(%s)) * cos(radians(latitude)) * 
             cos(radians(longitude) - radians(%s)) + sin(radians(%s)) * 
             sin(radians(latitude)))) <= %s
        )
        """
        
        risk_params = (lat1, lng1, lat1, threat_radius, lat2, lng2, lat2, threat_radius)
        risk_data = execute_query(risk_query, risk_params, fetch=True)
        
        if risk_data and risk_data[0]['threat_count']:
            threats_count = risk_data[0]['threat_count']
            avg_severity = float(risk_data[0]['avg_severity'] or 5)
            risk_score = min(10.0, (threats_count * 0.5) + (avg_severity * 0.5))
        else:
            threats_count = 0
            risk_score = 2.0  # Base risk score
        
        # Store route in database
        route_data = {
            'origin_address': data['origin_address'],
            'origin_lat': lat1,
            'origin_lng': lng1,
            'destination_address': data['destination_address'],
            'destination_lat': lat2,
            'destination_lng': lng2,
            'distance_km': round(distance, 2),
            'estimated_time_minutes': estimated_time,
            'risk_score': round(risk_score, 1),
            'threat_radius_km': threat_radius,
            'travel_time': data.get('travel_time', 'morning'),
            'vehicle_type': data.get('vehicle_type', 'sedan'),
            'threats_count': threats_count
        }
        
        insert_query = """
        INSERT INTO routes (
            origin_address, origin_lat, origin_lng,
            destination_address, destination_lat, destination_lng,
            distance_km, estimated_time_minutes, risk_score,
            threat_radius_km, travel_time, vehicle_type, threats_count
        ) VALUES (
            %(origin_address)s, %(origin_lat)s, %(origin_lng)s,
            %(destination_address)s, %(destination_lat)s, %(destination_lng)s,
            %(distance_km)s, %(estimated_time_minutes)s, %(risk_score)s,
            %(threat_radius_km)s, %(travel_time)s, %(vehicle_type)s, %(threats_count)s
        )
        """
        
        route_id = execute_query(insert_query, route_data)
        
        return jsonify({
            "success": True,
            "route_id": route_id,
            "data": {
                "distance_km": route_data['distance_km'],
                "estimated_time_minutes": estimated_time,
                "estimated_time_formatted": f"{estimated_time // 60}h {estimated_time % 60}m",
                "risk_score": route_data['risk_score'],
                "threats_count": threats_count,
                "route_geometry": f"LINESTRING({lng1} {lat1}, {lng2} {lat2})"
            },
            "timestamp": datetime.utcnow().isoformat()
        })
        
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e),
            "timestamp": datetime.utcnow().isoformat()
        }), 500

@app.route("/api/reports", methods=["POST"])
def generate_report():
    """Generate and store PDF report"""
    try:
        data = request.get_json()
        route_id = data.get('route_id')
        report_type = data.get('report_type', 'route_assessment')
        
        # Create report record
        report_data = {
            'route_id': route_id,
            'report_type': report_type,
            'title': f'Crime Risk Assessment Report - {datetime.now().strftime("%Y-%m-%d %H:%M")}',
            'description': 'Comprehensive crime risk assessment and route analysis',
            'file_name': f'report_{datetime.now().strftime("%Y%m%d_%H%M%S")}.pdf',
            'status': 'completed',
            'executive_summary': 'Route analysis completed with risk assessment and safety recommendations.',
            'risk_assessment': f'Overall risk score calculated based on recent crime data and threat analysis.',
            'recommendations': 'Follow recommended route and avoid high-risk areas during specified times.'
        }
        
        insert_query = """
        INSERT INTO reports (
            route_id, report_type, title, description, file_name,
            status, executive_summary, risk_assessment, recommendations
        ) VALUES (
            %(route_id)s, %(report_type)s, %(title)s, %(description)s, %(file_name)s,
            %(status)s, %(executive_summary)s, %(risk_assessment)s, %(recommendations)s
        )
        """
        
        report_id = execute_query(insert_query, report_data)
        
        return jsonify({
            "success": True,
            "report_id": report_id,
            "file_name": report_data['file_name'],
            "message": "Report generated successfully",
            "timestamp": datetime.utcnow().isoformat()
        })
        
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e),
            "timestamp": datetime.utcnow().isoformat()
        }), 500

@app.route("/api/dashboard-stats")
def get_dashboard_stats():
    """Get dashboard statistics"""
    try:
        # Get total incidents
        total_query = "SELECT COUNT(*) as total FROM crime_incidents WHERE incident_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)"
        total_result = execute_query(total_query, fetch=True)
        total_incidents = total_result[0]['total'] if total_result else 0
        
        # Get high risk areas count
        areas_query = "SELECT COUNT(*) as count FROM areas WHERE risk_level >= 7 AND is_active = TRUE"
        areas_result = execute_query(areas_query, fetch=True)
        high_risk_areas = areas_result[0]['count'] if areas_result else 0
        
        # Get routes count
        routes_query = "SELECT COUNT(*) as count FROM routes WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)"
        routes_result = execute_query(routes_query, fetch=True)
        safe_routes = routes_result[0]['count'] if routes_result else 0
        
        # Get community reports (using data_sources as proxy)
        community_query = "SELECT SUM(records_scraped) as total FROM data_sources WHERE source_type = 'community'"
        community_result = execute_query(community_query, fetch=True)
        community_reports = community_result[0]['total'] if community_result and community_result[0]['total'] else 0
        
        return jsonify({
            "success": True,
            "data": {
                "total_incidents": total_incidents,
                "high_risk_areas": high_risk_areas,
                "safe_routes": safe_routes,
                "community_reports": community_reports
            },
            "timestamp": datetime.utcnow().isoformat()
        })
        
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e),
            "timestamp": datetime.utcnow().isoformat()
        }), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)

